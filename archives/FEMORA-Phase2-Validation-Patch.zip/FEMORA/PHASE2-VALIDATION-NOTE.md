# FEMORA Phase 2 — Validation Patch

## Change
- `src/data/access.ts`: `validateWrite()` now rejects writes through `scoped.add()` when a table has no registered input schema, instead of silently passing the input through unvalidated.
- `tests/core.test.ts`: adds a regression test that the scoped write API fails closed for a table without an input schema.

## Why
A missing schema must not disable validation silently. Explicitly managed tables such as profiles/settings should continue to use their dedicated APIs; this patch only closes the generic scoped-write fallback.

## Verification status
Automated checks were **not completed** in this environment because `npm ci` timed out before dependencies were installed. Do not treat this patch as test-passing or production-ready until checks run locally.

## Apply
From the FEMORA repository root, run:

```bash
git apply FEMORA-Phase2-Validation.patch
npm ci
npm run typecheck
npm test
npm run lint
npm run build
```

If applying the patch file from a different folder, provide its full path to `git apply`.
