﻿import { ZodError } from 'zod';
import { evaluateSafety } from '../safety';
import {
  CoreError,
  profiles,
  getProfileEncryptionStatus,
  deleteCheckIn,
  deleteRecord,
  listRecords,
  dataRepositories,
  getStoragePersistenceStatus,
  getStoragePersistenceDetails,
  sampleData
} from './access';
import { saveCheckIn, getCheckInHistory } from '../journeys/checkins';
import { switchJourney } from '../core/journeys';
import { createBackup, restoreBackup } from '../core/backup/backup';
import { enablePin, unlock, lock, touch } from '../core/security/vault';
import {
  saveMenstrualCheckIn,
  menstrualSummary
} from '../journeys/menstrual';
import {
  saveMaternityCheckIn,
  maternityTimelineForProfile,
  savePregnancyDates,
  saveBirthPlan,
  addHospitalChecklistItem,
  addDoctorQuestion,
  addMaternityAppointment,
  transitionToPostpartum
} from '../journeys/maternity';
import {
  saveMenopauseCheckIn,
  menopauseTrends,
  saveHealthHistory,
  saveTreatmentHistory,
  addMenopauseDoctorQuestion,
  addMenopauseAppointment
} from '../journeys/menopause';
import type { Journey, EncryptedBackup, BaseEntity } from '../core/contracts';
import type { Vault } from '../core/security/vault';

export type ErrorCode =
  | 'VALIDATION'
  | 'STORAGE_FULL'
  | 'LOCKED'
  | 'NOT_FOUND'
  | 'CONFLICT'
  | 'CRYPTO'
  | 'UNKNOWN';

export type Result<T> =
  | { ok: true; data: T }
  | { ok: false; code: ErrorCode; message: string };

function isQuotaError(error: unknown) {
  return !!error &&
    typeof error === 'object' &&
    'name' in error &&
    (
      (error as { name: string }).name === 'QuotaExceededError' ||
      (error as { name: string }).name === 'NS_ERROR_DOM_QUOTA_REACHED'
    );
}

function errorCode(value: unknown): ErrorCode {
  return value === 'VALIDATION' ||
    value === 'STORAGE_FULL' ||
    value === 'LOCKED' ||
    value === 'NOT_FOUND' ||
    value === 'CONFLICT' ||
    value === 'CRYPTO' ||
    value === 'UNKNOWN'
    ? value
    : 'UNKNOWN';
}

type UnwrapOperation<T> =
  T extends { ok: true; data: infer D }
    ? D
    : T extends { ok: false }
      ? never
      : T;

async function run<T>(
  operation: () => Promise<T>
): Promise<Result<UnwrapOperation<Awaited<T>>>> {
  try {
    const value: unknown = await operation();

    if (value && typeof value === 'object' && 'ok' in value) {
      const nested = value as {
        ok: boolean;
        data?: unknown;
        code?: string;
        message?: string;
      };

      return (
        nested.ok
          ? { ok: true, data: nested.data }
          : {
              ok: false,
              code: errorCode(nested.code),
              message: nested.message ?? 'Operation failed'
            }
      ) as Result<UnwrapOperation<Awaited<T>>>;
    }

    return {
      ok: true,
      data: value as UnwrapOperation<Awaited<T>>
    };
  } catch (error) {
    const code: ErrorCode =
      error instanceof ZodError
        ? 'VALIDATION'
        : error instanceof CoreError
          ? error.code
          : isQuotaError(error)
            ? 'STORAGE_FULL'
            : 'UNKNOWN';

    return {
      ok: false,
      code,
      message:
        error instanceof CoreError
          ? error.message
          : code === 'VALIDATION'
            ? 'Input failed validation'
            : 'Operation failed'
    };
  }
}

type Repository<T extends BaseEntity> = {
  create: (
    profileId: string,
    value: Omit<T, 'id' | 'profileId' | 'createdAt' | 'updatedAt'>
  ) => Promise<T>;
  get: (profileId: string, id: string) => Promise<T>;
  list: (profileId: string) => Promise<T[]>;
  update: (profileId: string, id: string, patch: Partial<T>) => Promise<T>;
  delete: (profileId: string, id: string) => Promise<void>;
  byJourney: (profileId: string, journey: string) => Promise<T[]>;
  byType: (
    profileId: string,
    type: string,
    journey?: string
  ) => Promise<T[]>;
  byDate: (
    profileId: string,
    start: string,
    end: string
  ) => Promise<T[]>;
};

function publicRepository<T extends BaseEntity>(repo: Repository<T>) {
  return {
    create: (
      profileId: string,
      value: Omit<T, 'id' | 'profileId' | 'createdAt' | 'updatedAt'>
    ) => run(() => repo.create(profileId, value)),
    get: (profileId: string, id: string) =>
      run(() => repo.get(profileId, id)),
    list: (profileId: string) => run(() => repo.list(profileId)),
    update: (profileId: string, id: string, patch: Partial<T>) =>
      run(() => repo.update(profileId, id, patch)),
    delete: (profileId: string, id: string) =>
      run(() => repo.delete(profileId, id)),
    byJourney: (profileId: string, journey: string) =>
      run(() => repo.byJourney(profileId, journey)),
    byType: (profileId: string, type: string, journey?: string) =>
      run(() => repo.byType(profileId, type, journey)),
    byDate: (profileId: string, start: string, end: string) =>
      run(() => repo.byDate(profileId, start, end))
  };
}

export const coreApi = {
  evaluateSafety: (journey: Journey, payload: unknown) =>
    evaluateSafety(journey, payload),

  repositories: {
    healthProfile: publicRepository(dataRepositories.healthProfile),
    journeyProfiles: publicRepository(dataRepositories.journeyProfiles),
    checkins: publicRepository(dataRepositories.checkins),
    records: publicRepository(dataRepositories.records),
    appointments: publicRepository(dataRepositories.appointments),
    notifications: publicRepository(dataRepositories.notifications),
    bookmarks: publicRepository(dataRepositories.bookmarks),
    recentlyViewed: publicRepository(dataRepositories.recentlyViewed),
    consents: publicRepository(dataRepositories.consents)
  },

  createProfile: (name: string) => run(() => profiles.create(name)),
  getStoragePersistenceStatus: () =>
    run(() => getStoragePersistenceDetails()),
  isStoragePersistenceGranted: () =>
    run(() => getStoragePersistenceStatus()),
  listProfiles: () => run(() => profiles.list()),
  getActiveProfile: () => run(() => profiles.active()),
  selectProfile: (profileId: string) =>
    run(() => profiles.select(profileId)),

  updateProfile: (
    profileId: string,
    patch: { displayName?: string; activeJourney?: Journey }
  ) =>
    run(async () => ({
      ...await profiles.update(profileId, patch),
      isEncrypted: await getProfileEncryptionStatus(profileId)
    })),

  deleteProfile: (profileId: string) => run(() => profiles.delete(profileId)),
  wipeProfile: (profileId: string) => run(() => profiles.wipe(profileId)),
  loadSampleData: (profileId: string) =>
    run(() => sampleData.load(profileId)),
  resetSampleData: (profileId: string) =>
    run(() => sampleData.reset(profileId)),

  saveCheckIn: (profileId: string, input: unknown) =>
    run(() => saveCheckIn(profileId, input)),
  getCheckIns: (profileId: string, journey?: Journey) =>
    run(() => getCheckInHistory(profileId, journey)),
  deleteCheckIn: (profileId: string, id: string) =>
    run(() => deleteCheckIn(profileId, id)),
  listRecords: (profileId: string, journey?: Journey) =>
    run(() => listRecords(profileId, journey)),
  deleteRecord: (profileId: string, id: string) =>
    run(() => deleteRecord(profileId, id)),
  switchJourney: (profileId: string, journey: Journey) =>
    run(() => switchJourney(profileId, journey)),

  saveMenstrualCheckIn: (profileId: string, input: unknown) =>
    run(() => saveMenstrualCheckIn(profileId, input)),
  menstrualSummary: (profileId: string, asOf: string) =>
    run(() => menstrualSummary(profileId, asOf)),
  saveMaternityCheckIn: (profileId: string, input: unknown) =>
    run(() => saveMaternityCheckIn(profileId, input)),
  maternityTimeline: (profileId: string, asOf: string) =>
    run(() => maternityTimelineForProfile(profileId, asOf)),
  savePregnancyDates: (profileId: string, input: unknown) =>
    run(() => savePregnancyDates(profileId, input)),
  saveBirthPlan: (profileId: string, input: unknown) =>
    run(() => saveBirthPlan(profileId, input)),
    addHospitalChecklistItem: (profileId: string, input: unknown) =>
      run(() => addHospitalChecklistItem(profileId, input)),
    addDoctorQuestion: (profileId: string, input: unknown) =>
      run(() => addDoctorQuestion(profileId, input)),
    addMaternityAppointment: (
      profileId: string,
      input: { dateTime: string; title: string; notes?: string }
    ) => run(() => addMaternityAppointment(profileId, input)),
    transitionToPostpartum: (profileId: string, date: string) =>
      run(() => transitionToPostpartum(profileId, date)),

    saveMenopauseCheckIn: (profileId: string, input: unknown) =>
      run(() => saveMenopauseCheckIn(profileId, input)),
    menopauseTrends: (
      profileId: string,
      windowDays: number,
      asOf: string
    ) => run(() => menopauseTrends(profileId, windowDays, asOf)),
    saveHealthHistory: (profileId: string, input: unknown) =>
      run(() => saveHealthHistory(profileId, input)),
    saveTreatmentHistory: (profileId: string, input: unknown) =>
      run(() => saveTreatmentHistory(profileId, input)),
    addMenopauseDoctorQuestion: (profileId: string, input: unknown) =>
      run(() => addMenopauseDoctorQuestion(profileId, input)),
    addMenopauseAppointment: (
      profileId: string,
      input: { dateTime: string; title: string; notes?: string }
    ) => run(() => addMenopauseAppointment(profileId, input)),

    enablePin: (profileId: string, pin: string) =>
      run(() => enablePin(profileId, pin)),
    unlock: (profileId: string, pin: string) =>
      run(() => unlock(profileId, pin)),
    touch: (vault: Vault) =>
      run(async () => {
        touch(vault);
        if (vault.locked || !vault.key) {
          throw new CoreError('LOCKED', 'Profile is locked');
        }
        return true;
      }),
    lock: (vault: Vault) =>
      run(async () => {
        lock(vault);
        return true;
      }),

    exportBackup: (profileId: string, credential?: Vault) =>
      run(() => createBackup(profileId, credential)),
    restoreBackup: (
      credential: string | Vault | undefined,
      backup: EncryptedBackup
    ) => run(() => restoreBackup(credential, backup))
};
