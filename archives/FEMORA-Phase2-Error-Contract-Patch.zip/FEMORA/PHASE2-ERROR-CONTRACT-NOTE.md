# FEMORA Phase 2 — Standardized Error Contract Tests

## Change
- Adds regression coverage that unexpected repository errors are returned as `{ ok: false, code: 'UNKNOWN', message: 'Operation failed' }` without leaking the underlying exception message.
- Adds regression coverage that cross-profile access is surfaced through the public API as a structured `LOCKED` result.

## Scope
This is a test-only patch. It does not change runtime behavior or mark clinical requirements as approved.

## Verification status
Not run in this environment. Apply the patch to the same code revision as the prior Phase 2 validation patch, then run the project's normal typecheck, tests, lint, and build commands. The source snapshot available here did not include a verified complete install/runtime, so these tests must not be described as passing until run locally.

## Apply
From the repository root:

```bash
git apply FEMORA-Phase2-Error-Contract.patch
```
